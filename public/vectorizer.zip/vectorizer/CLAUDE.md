# Cmap — Diplomacy-map PNG → SVG vectorizer

This directory contains a pipeline that converts a Diplomacy-style game-board PNG
into a layered, topologically-correct SVG. The single source file is
[vectorize_map.py](vectorize_map.py). Run it as:

```
python3 vectorize_map.py <input.png> <output.svg>
```

A typical PNG depicts a region of Earth with: tan-coloured land provinces, blue
sea provinces, dark borders between provinces, dashed sea-route lines, plus
overlays (province name labels, supply-center stars, unit dots/triangles, an
optional legend / SC panel).

## Output SVG layer contract

Order is back → front. **Do not** change layer ordering or remove a layer
without checking what depends on it.

```
<g id="background">       2 paths: bg-sea (all sea unioned), bg-land (all land unioned)
<g id="provinces">        one filled <path> per province, no stroke
<g id="named-provinces">  empty placeholder
<g id="borders">          deduplicated province borders, sub-grouped:
   <g class="border-land-land">
   <g class="border-land-sea">
   <g class="border-sea-sea" stroke-dasharray="8 5">   (dashed bezier-style)
<g id="SCs">              empty placeholder
<g id="foreground">       empty placeholder
<g id="names">            empty placeholder
<g id="unit-positions">   empty placeholder
```

The empty placeholder groups (`named-provinces`, `SCs`, `foreground`, `names`,
`unit-positions`) are emitted unconditionally so downstream tooling can
populate them in place without altering ordering. Don't remove them.

### Topology contract (must hold for every output)

- Every province polygon is valid (no self-intersections, no degenerate rings).
- No two province polygons overlap.
- Each border polyline (in the `borders` group) is shared between exactly two
  province polygons (or one province + the outer frame). Adjacent provinces
  share bit-identical coordinates on their shared boundary.
- The union of all province polygons covers ≥ ~99% of the image area (the
  remaining ~0.2% is the outer frame).

The verification snippet at the bottom of this file checks these invariants.

## Pipeline at a glance

1. **Pixel classification** (`build_masks`): every pixel is one of border /
   land-fill / sea-fill / overlay.
2. **Bridge dashed lines**: morphological close of the dark mask so dashed
   sea-route lines act as solid borders for segmentation.
3. **Per-type connected-component labeling** (`segment_provinces`): land and
   sea are labeled **separately**, so a land↔sea pixel transition becomes a
   natural boundary even where no dark line is drawn (coastlines).
4. **Watershed expansion**: borders get absorbed into the nearest label.
5. **Contour extraction → planar graph** (`vectorize`): per-label
   `find_contours @ level=0.5` (gives bit-identical shared edges) → `unary_union`
   → `linemerge` → simplify.
6. **Per-type border transformation**:
   - `land-land`: subdivide + 2D fractal-noise displacement perpendicular to
     the line + 1 pass of Chaikin smoothing.
   - `land-sea`: same but smaller amplitude / finer wavelength, more
     subdivision (coastlines "upscaled" with extra detail).
   - `sea-sea`: subdivide + 3 passes of Chaikin → smooth bezier-like curve,
     rendered dashed.
   - Junctions are tapered so adjacent polylines stay connected exactly.
7. **Re-polygonize + union by label**: the transformed polylines are
   re-noded, polygonized, and per-province faces are unioned. Sub-pixel
   artifacts at junctions are absorbed; `make_valid` fixes any self-intersections.
8. **Emit SVG** with the four layers above.

## The tunables, grouped

All tunables live at the top of `vectorize_map.py`. Defaults work for the
Iberia map and the N.Africa map shipped with this project.

### Colour-based pixel classification

| Tunable | Effect | When to change |
|---|---|---|
| `LAND_RGBS` | list of land reference RGBs. Any pixel within `COLOR_TOL` of any entry is "land". | New map uses a different tan, or has visibly shaded land variants. |
| `SEA_RGBS` | list of sea reference RGBs. | New map uses a different blue/cyan, or has a dark "coastal fringe" gradient. **Different maps often pick different cyans** — defaults already cover `(0,250,250)` pure cyan, `(0,200,250)` mid-cyan, `(112,146,190)` muted blue, and `(67,101,148)` dark coastal fringe. Always sample first (step 2 below); the dominant `B > R` cluster is your sea reference. If `sea: 0` appears in the run log, the dominant colour is outside `COLOR_TOL` of every entry — add it. |
| `LAND_FILL`, `SEA_FILL` | RGB used to **render** province fill in the SVG. | If you want the output recoloured (independent of source colours). |
| `COLOR_TOL` | max Euclidean distance from a reference colour. | Source has wider variance per region (raise to ~50). Don't go too high or borders / overlays bleed into fills. |

### Border detection

| Tunable | Effect | When to change |
|---|---|---|
| `BORDER_MAX_BRIGHTNESS` | R+G+B threshold for "dark"; lower = stricter. | Borders are pure black: ~60. Antialiased / brown borders: ~200–250. |
| `BORDER_MIN_RB_DIFF` | required `R − B`; ≥0 keeps borders brown and rejects dark blue (sea-fringe). | Borders are coloured: lower or set to large negative. |
| `DASH_BRIDGE_KERNEL` | morphological-close kernel in px, applied before connected-component analysis. Bridges hand-drawn gaps and dashed sea-route gaps so they form one CC. | Border network is fragmented at default → raise (try 10–14). Text labels start joining borders → lower. |
| `BORDER_CC_MIN` | minimum size of a closed dark CC to count as a border (vs. text). | Borders are short / archipelagic: lower (200). Text words are merging into borders: raise. |

### Segmentation / vectorization

| Tunable | Effect |
|---|---|
| `MIN_PROVINCE_AREA` | drops stray fill components below this. |
| `MIN_POLYGON_AREA` | drops sub-pixel polygonize artifacts. |
| `EXPAND_DIST` | watershed radius for filling border/overlay pixels with the nearest label. |
| `SIMPLIFY_TOL` | Douglas-Peucker tolerance on the planar graph. |
| `EXCLUDE_FRAME` | drops borders that lie entirely on the outer image rectangle. |

### Natural-border noise

`NATURAL_BORDERS = False` turns off the per-type transformation entirely
(useful for debugging — emits straight polylines).

| Tunable | Effect | Typical range |
|---|---|---|
| `NOISE_OCTAVES` | number of frequencies summed (multi-scale "fractal"). | 4–6 |
| `NOISE_PERSISTENCE` | amplitude per octave; higher = more visible high-freq detail. | 0.55–0.7 |
| `LL_NOISE_AMPLITUDE` | px peak displacement for land-land borders. | 2.0–4.0; **larger amplitude can cause polyline crossings → broken topology** |
| `LL_NOISE_SCALE` | base wavelength px; smaller = more wiggles per length. | 10–35 |
| `LL_SUBDIVIDE` | max segment length before noise; smaller = finer noise capture. | 1.0–2.0 |
| `LL_POST_SMOOTH_ITER` | Chaikin passes after displacement, rounds sharp corners. | 0–2 |
| `LS_*` | same family for land-sea (coastline). Smaller amplitude + finer scale = more "upscaling" of simple coasts. | |
| `SS_SUBDIVIDE`, `SS_SMOOTH_ITER`, `SS_DASH` | sea-sea bezier-like curves + dash pattern. | |
| `NOISE_TAPER_FRACTION` | fraction of each polyline's ends that taper to zero displacement; preserves junction connections. | 0.05–0.15 |

## Grooming a new map — step-by-step

When the user drops a new `map.png` in this directory and says "it doesn't look
right":

### 1. Inspect the source

```bash
file map.png
```
Note the dimensions. Then look at it with the Read tool to see the visual style.

### 2. Sample dominant colours

```bash
python3 -c "
import numpy as np
from PIL import Image
img = np.array(Image.open('map.png').convert('RGB'))
flat = img.reshape(-1, 3)
q = (flat // 10) * 10
unique, counts = np.unique(q, axis=0, return_counts=True)
order = np.argsort(-counts)
print('Top 15 quantized colours:')
for i in order[:15]:
    print(f'  RGB={tuple(int(x) for x in unique[i])}, count={counts[i]}')
"
```

You're looking for:
- One or more **land** colours (warm tan, R > B).
- One or more **sea** colours (blue, B > R).
- The **border** colour — usually a low-count entry with low brightness.

If land/sea differ from current `LAND_RGBS` / `SEA_RGBS`, update those lists.

### 3. Verify border detection

```bash
python3 -c "
import numpy as np
from PIL import Image
from skimage import measure, morphology
img = np.array(Image.open('map.png').convert('RGB'))
rgb_sum = img.astype(np.int32).sum(-1)
r_b = img[...,0].astype(np.int32) - img[...,2].astype(np.int32)
for thresh in [100, 150, 200, 250, 300]:
    dark = (rgb_sum < thresh) & (r_b >= -5)
    for k in [6, 8, 10, 12]:
        closed = morphology.binary_closing(dark, morphology.square(k))
        labels = measure.label(closed, connectivity=2)
        sizes = np.bincount(labels.ravel()); sizes[0] = 0
        big = int((sizes >= 400).sum())
        biggest = int(sizes.max()) if len(sizes) else 0
        print(f'thresh={thresh} k={k}: CCs={int((sizes>0).sum())}, >=400px: {big}, biggest: {biggest}')
"
```

A healthy border network gives **one CC much larger than the rest** (≥ ~5000 px
on a 1500-px-wide map). If you don't see that:
- Raise `BORDER_MAX_BRIGHTNESS` (the line edges fade into the fill).
- Raise `DASH_BRIDGE_KERNEL` (the line has gaps wider than the current kernel).
- If multiple roughly-equal CCs persist, the border network is truly
  fragmented; consider raising the kernel further OR lowering `BORDER_CC_MIN`.

### 4. First run

```bash
python3 vectorize_map.py map.png map.svg
```

Watch the log line `seg_border px: X, real_border: Y` — if `seg_border` is
small relative to image size (< 0.5%), border detection is still bad.

### 5. Render preview

For aspect ratios up to ~1.6:1, qlmanage + resize works:

```bash
qlmanage -t -s 1500 -o . map.svg 2>&1 | tail -1
python3 -c "
from PIL import Image
img = Image.open('map.svg.png')
# qlmanage produces a square thumbnail; resize back to native to undo squish.
src_w, src_h = 1493, 893   # ← read from `file map.png` above
img.resize((src_w, src_h), Image.LANCZOS).save('preview.png')
"
```

For wider maps (qlmanage truncates content past the square crop), render the
SVG paths directly:

```bash
python3 -c "
import re
from PIL import Image, ImageDraw
W, H = 1640, 801   # ← read from \`file map.png\`
img = Image.new('RGB', (W, H), (200, 200, 240))
draw = ImageDraw.Draw(img)
data = open('map.svg').read()
prov = re.search(r'<g id=\"provinces\"[^>]*>(.*?)</g>', data, re.DOTALL).group(1)
for d, fill in re.findall(r'd=\"([^\"]+)\"\s*fill=\"([^\"]+)\"', prov):
    for ring in d.split('M')[1:]:
        pts = re.findall(r'(-?\d+\.\d+),(-?\d+\.\d+)', ring)
        if len(pts) >= 3:
            coords = [(float(x), float(y)) for x, y in pts]
            rgb = tuple(int(fill[i:i+2], 16) for i in (1, 3, 5))
            draw.polygon(coords, fill=rgb, outline='black')
img.save('preview.png')
"
```

Then `Read /Users/658461/Development/dipmap/Dmap/preview.png` to view.

### 6. Verify topology

```bash
python3 -c "
import re, xml.etree.ElementTree as ET, collections
from shapely.geometry import Polygon
ns = {'svg': 'http://www.w3.org/2000/svg'}
tree = ET.parse('map.svg'); root = tree.getroot()
def parse(d):
    rings, cur, i = [], [], 0
    tokens = re.findall(r'[MLZ]|-?\d+\.?\d*', d)
    while i < len(tokens):
        t = tokens[i]
        if t == 'M':
            if cur: rings.append(cur)
            cur = [(float(tokens[i+1]), float(tokens[i+2]))]; i += 3
        elif t == 'L': cur.append((float(tokens[i+1]), float(tokens[i+2]))); i += 3
        elif t == 'Z':
            if cur: rings.append(cur); cur = []
            i += 1
        else: i += 1
    if cur: rings.append(cur)
    return rings
def round_pt(p): return (round(p[0],4), round(p[1],4))
provs, prov_es = [], []; invalid = 0
for g in root.findall('svg:g', ns):
    if g.get('id') == 'provinces':
        for p in g.findall('svg:path', ns):
            rings = parse(p.get('d',''))
            if not rings: continue
            try:
                poly = Polygon(rings[0], rings[1:])
                if poly.is_valid:
                    provs.append(poly)
                    es = set()
                    for ring in rings:
                        for i in range(len(ring)-1):
                            es.add(frozenset((round_pt(ring[i]),round_pt(ring[i+1]))))
                    prov_es.append(es)
                else: invalid += 1
            except: invalid += 1
W, H = root.get('viewBox').split()[2:]; W, H = int(float(W)), int(float(H))
print(f'valid: {len(provs)}, invalid: {invalid}, area: {sum(p.area for p in provs):.0f}/{W*H}')
overlap = sum(1 for i in range(len(provs)) for j in range(i+1,len(provs))
              if provs[i].intersects(provs[j]) and provs[i].intersection(provs[j]).area > 0.001)
print(f'overlapping pairs: {overlap}')
fg = set()
for g in root.findall('svg:g', ns):
    if g.get('id') == 'borders':
        for sg in g.findall('svg:g', ns):
            for p in sg.findall('svg:path', ns):
                tokens = re.findall(r'[ML]|-?\d+\.?\d*', p.get('d',''))
                pts = []; i = 0
                while i < len(tokens):
                    if tokens[i] in ('M','L'):
                        pts.append((float(tokens[i+1]), float(tokens[i+2]))); i += 3
                    else: i += 1
                for i in range(len(pts)-1):
                    fg.add(frozenset((round_pt(pts[i]),round_pt(pts[i+1]))))
counts = [sum(1 for es in prov_es if e in es) for e in fg]
print(f'fg edges: {len(fg)}, share-count distribution: {collections.Counter(counts)}')
"
```

Healthy output:
- `invalid: 0`
- `overlapping pairs: 0`
- area ≥ 99% of image
- share-count distribution dominated by `2:` (each border between exactly 2
  provinces); only frame edges should appear as `1:`.

### 7. If topology breaks under noise

If `invalid > 0` or area coverage drops, the noise displacement is too
aggressive for the new map's geometry. Reduce in this priority order:
1. `LL_NOISE_AMPLITUDE` and `LS_NOISE_AMPLITUDE` (down ~25%).
2. `LL_SUBDIVIDE` / `LS_SUBDIVIDE` up to 1.5–2.0 (fewer vertices = less wobble).
3. `NOISE_PERSISTENCE` down to 0.55–0.6 (smoother).

### 8. If the natural look is wrong

- Too smooth ("sine-wave"-looking): raise `NOISE_OCTAVES` (5–6),
  `NOISE_PERSISTENCE` (0.65–0.7), drop `LL_SUBDIVIDE` toward 1.0.
- Too jagged ("Z-pattern", visible vertex angles): raise
  `LL_POST_SMOOTH_ITER` to 1–2.
- Wiggles too small/large: change `LL_NOISE_SCALE` (smaller = more wiggles per
  unit length).

### 9. Clean up temp files

```bash
rm -f preview.png compare.png map.svg.png borders_only.svg borders_only.svg.png
```

## Known quirks

- **Legend / SC panels inside the image bounds** (e.g. the row of territory
  chips at the top of the N.Africa map, the supply-center panel at the bottom)
  are inside the playable rect and get treated as map area. They show up as
  extra "provinces". Today there's no automatic crop; the user can either
  pre-crop the PNG or accept the extra polygons.
- **qlmanage SVG rendering** squishes the SVG to a square thumbnail (e.g.
  1280×1078 → 1280×1280). Always resize back to native aspect ratio when
  reading the preview.
- **qlmanage fails on wide SVGs.** For aspect ratios ≳ 1.6:1 (e.g. the Central
  America map at 1640×801), qlmanage's output appears truncated even after
  resizing — content past roughly the square crop is missing. Bypass it: parse
  the `<g id="provinces">` paths from the SVG and rasterise via
  `PIL.ImageDraw.polygon` directly at the source dimensions. A minimal renderer
  is ~15 lines (regex out `d="..." fill="..."`, split on `M`, draw each ring).
  This also bypasses the squish workaround entirely.
- **Aggressive noise + thin borders** = self-intersecting polygons. The
  `make_valid` + dedupe step catches most of these; if a few slip through,
  reduce amplitude.

## What NOT to change without thinking

- Layer order in `write_svg` — downstream tools may rely on it.
- The polygonize → union-by-label trick in `vectorize` — without it,
  sub-pixel triangular artifacts at 3-province junctions become bogus
  microscopic provinces.
- The endpoint taper in `displace_along_normal` — without it, adjacent
  polylines stop meeting at junctions and the planar graph falls apart.
- The `EXPAND_DIST` watershed step — without it, border pixels belong to no
  province and the segmentation has gaps.
