#!/usr/bin/env python3
"""Convert a Diplomacy-style map PNG into a layered SVG.

Output structure (back -> front):
  <svg viewBox="0 0 W H">
    <g id="background">       unioned land + sea fills
    <g id="provinces">        filled polygons, shared boundaries (no overlap, no gaps)
    <g id="named-provinces">  (placeholder)
    <g id="borders">          deduplicated single-line borders between provinces
    <g id="foreground">       (placeholder)
    <g id="names">            (placeholder)
    <g id="unit-positions">   (placeholder)
    <g id="input-map">        <image> with the stripped artifacts (text, units, stars, legend)
  </svg>

Usage:
  python vectorize_map.py <input.png> <output.svg>
"""

import argparse
import base64
import io
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from skimage import measure, morphology, segmentation
from collections import defaultdict

from scipy import ndimage as ndi
from shapely.geometry import LineString, MultiLineString, Polygon, MultiPolygon
from shapely.ops import unary_union, polygonize, linemerge
from shapely.validation import make_valid

# ---- Tunables (defaults work for the Iberia + N.Africa style maps) ----
# Multiple reference colours per type let us handle maps that shade coastlines
# or use two-tone sea/land. Any pixel within COLOR_TOL of *any* reference of
# its type is classified as that type.
LAND_RGBS = [
    (192, 160, 128),   # main tan
    (160, 120, 80),    # darker land variant (some maps shade interior)
]
SEA_RGBS = [
    (0, 250, 250),     # pure cyan (Europe map)
    (0, 200, 250),     # main cyan (SE Asia map)
    (60, 60, 190),     # indigo (India/Asia map)
    (112, 146, 190),   # main bright blue
    (67, 101, 148),    # darker coastal fringe
]
LAND_FILL = (192, 160, 128)  # rgb used for filling land polygons in the SVG
SEA_FILL = (112, 146, 190)   # rgb used for filling sea polygons in the SVG
COLOR_TOL = 35               # max RGB Euclidean dist to be classified as a fill

# Borders may be black (Iberia) or dark brown (newer maps). Both share:
#   - low brightness (R+G+B below BORDER_MAX_BRIGHTNESS); raise for antialiased
#     brown borders whose edges fade toward the fill colour
#   - warm tone (R >= B) — distinguishes them from dark sea pixels
BORDER_MAX_BRIGHTNESS = 250  # R+G+B threshold for "dark" pixels (brown borders)
BORDER_MIN_RB_DIFF = -5      # R - B; >=0 favours brown, allows tiny tolerance
DASH_BRIDGE_KERNEL = 8       # px; closing kernel to bridge dashed gaps + thin border pieces
BORDER_CC_MIN = 400          # px; min size of a closed dark CC to count as a border (drops text)
MIN_PROVINCE_AREA = 100      # px; drop stray fill components below this
MIN_POLYGON_AREA = 50        # px; drop spurious micro-faces from polygonize
EXPAND_DIST = 30             # px; watershed expansion to fill borders / dashed gaps
SIMPLIFY_TOL = 0.6           # px; Douglas-Peucker tolerance after vectorization
# Figma-style "simplify path" applied AFTER per-type noise/smoothing but BEFORE
# polygonize. Since province polygons and foreground borders are both derived
# from the same `transformed` polylines, they inherit the simplification
# identically and stay aligned. Endpoints (junctions) are preserved by Douglas-
# Peucker, so adjacent polylines stay connected. Raise for more aggressive
# reduction (more bloat removed, less visual fidelity); lower to keep more
# detail. ~1.5 px drops ~80% of vertices on natural-border output.
FINAL_SIMPLIFY_TOL = 1.5
EXCLUDE_FRAME = True         # drop borders that lie on the outer image rectangle

# ---- Border styling (natural-looking borders) ----
NATURAL_BORDERS = True       # apply per-type transforms (noise / smoothing)
NOISE_SEED = 42
NOISE_OCTAVES = 6            # number of frequencies summed (multi-scale = "fractal")
NOISE_PERSISTENCE = 0.7      # amplitude per octave; closer to 1 = more high-freq roughness

# Land-land: dramatic bumps + fine angular roughness on top. Subdivide very
# finely so the small octaves of the noise field actually have vertices to
# displace, producing the "many small kinks" look of natural geographic borders.
LL_NOISE_AMPLITUDE = 3.5     # px ~peak displacement for land-land borders
LL_NOISE_SCALE = 12          # px base wavelength (smaller => more wiggles per unit length)
LL_SUBDIVIDE = 1.0           # px max segment length before noise
LL_POST_SMOOTH_ITER = 1      # Chaikin passes after displacement (smooths sharp corners)

# Land-sea (coastline): finer-scale than land-land so simple coasts get more
# high-freq detail added while macro shape is kept.
LS_NOISE_AMPLITUDE = 2.5     # px
LS_NOISE_SCALE = 10          # px
LS_SUBDIVIDE = 1.0           # px
LS_POST_SMOOTH_ITER = 1      # Chaikin passes after displacement

# Endpoint taper: only the first/last 5% of each polyline tapers to 0 displacement.
# Small taper preserves angular, "kinked" look at junctions (vs smooth sweep-in).
NOISE_TAPER_FRACTION = 0.05

# Sea-sea boundaries should be fluid, not faceted — we aggressively simplify
# the raw contour polyline first (few control points), then Chaikin-smooth so
# the resulting curve passes through those control points smoothly. This keeps
# the vertex count low on both province polygon edges AND the foreground border
# polyline (they share geometry by construction).
SS_PRE_SIMPLIFY_TOL = 8.0    # px; Douglas-Peucker tol applied before smoothing
SS_SUBDIVIDE = 6             # px max segment length before sea-sea smoothing
SS_SMOOTH_ITER = 3           # Chaikin corner-cutting passes; more = smoother
SS_DASH = "8 5"              # SVG stroke-dasharray for sea-sea borders


def color_distance(img, ref):
    diff = img.astype(np.int32) - np.array(ref, dtype=np.int32)
    return np.sqrt((diff ** 2).sum(-1))


def build_masks(img):
    """Classify every pixel into:
      - seg_border: pixels treated as boundary for segmentation (dark border lines
        AND the bridged gaps inside dashed sea-route lines).
      - real_border: only the actually-dark pixels within the seg_border (visual subset).
      - land_like / sea_like: fill-color pixels.
      - overlay_mask: small dark CCs (text glyphs) + bright non-fill (stars, units).
    """
    rgb_sum = img.astype(np.int32).sum(-1)
    # "Dark" = low brightness AND warm-toned (R >= B), so we exclude dark blue
    # sea-fringe pixels that just happen to be low-brightness.
    r_minus_b = img[..., 0].astype(np.int32) - img[..., 2].astype(np.int32)
    dark = (rgb_sum < BORDER_MAX_BRIGHTNESS) & (r_minus_b >= BORDER_MIN_RB_DIFF)

    land_like = np.zeros(img.shape[:2], dtype=bool)
    for ref in LAND_RGBS:
        land_like |= color_distance(img, ref) < COLOR_TOL
    sea_like = np.zeros(img.shape[:2], dtype=bool)
    for ref in SEA_RGBS:
        sea_like |= color_distance(img, ref) < COLOR_TOL

    # A larger closing bridges the gaps inside dashed sea-route lines so they
    # form one continuous CC. Solid borders are unaffected; isolated text glyphs
    # stay small and won't reach the BORDER_CC_MIN threshold.
    dark_closed = morphology.binary_closing(dark, morphology.square(DASH_BRIDGE_KERNEL))
    big_labels = measure.label(dark_closed, connectivity=2)
    sizes = np.bincount(big_labels.ravel())
    sizes[0] = 0
    keep_ids = np.where(sizes >= BORDER_CC_MIN)[0]

    # seg_border includes the bridge pixels: this disconnects sea components
    # along dashed lines just as effectively as solid drawn borders do.
    seg_border = np.isin(big_labels, keep_ids)
    real_border = seg_border & dark

    # Small dark CCs (= text glyphs and other tiny dark artifacts).
    text_overlay = dark & ~seg_border
    # Bright non-fill (= stars, unit dots/triangles, anti-aliasing on overlays).
    other_overlay = ~dark & ~land_like & ~sea_like
    overlay_mask = text_overlay | other_overlay

    return seg_border, real_border, land_like, sea_like, overlay_mask


def segment_provinces(seg_border, land_like, sea_like, overlay_mask):
    """Label land and sea components separately so coastlines (land directly
    adjacent to sea, with no drawn line between them) become natural province
    boundaries in the label image. Watershed then fills borders & overlays."""
    land_seeds = land_like & ~seg_border & ~overlay_mask
    sea_seeds = sea_like & ~seg_border & ~overlay_mask

    land_labels = measure.label(land_seeds, connectivity=1)
    sea_labels = measure.label(sea_seeds, connectivity=1)

    H, W = land_labels.shape
    final = np.zeros((H, W), dtype=np.int32)
    meta = {}
    next_id = 1
    land_fill = "#%02x%02x%02x" % LAND_FILL
    sea_fill = "#%02x%02x%02x" % SEA_FILL

    for lbl in range(1, int(land_labels.max()) + 1):
        comp = land_labels == lbl
        if comp.sum() < MIN_PROVINCE_AREA:
            continue
        final[comp] = next_id
        meta[next_id] = {"type": "land", "fill": land_fill}
        next_id += 1

    for lbl in range(1, int(sea_labels.max()) + 1):
        comp = sea_labels == lbl
        if comp.sum() < MIN_PROVINCE_AREA:
            continue
        final[comp] = next_id
        meta[next_id] = {"type": "sea", "fill": sea_fill}
        next_id += 1

    # Expand each label outward into border / overlay / unclassified pixels.
    expanded = segmentation.expand_labels(final, distance=EXPAND_DIST)
    return expanded, meta


def make_fractal_noise(H, W, scale, seed, octaves=NOISE_OCTAVES,
                       persistence=NOISE_PERSISTENCE):
    """Multi-octave smoothed-random noise field, shape (H, W).

    Sums octaves of upscaled white noise so the result has features at multiple
    wavelengths (base `scale`, `scale/2`, `scale/4`, ...). Output is normalized
    so 1 sigma ~ 1, so callers can multiply by an amplitude in pixels directly.
    """
    rng = np.random.RandomState(seed)
    field = np.zeros((H, W), dtype=np.float64)
    amp = 1.0
    total = 0.0
    for o in range(octaves):
        s = max(2, int(scale / (2 ** o)))
        sh = max(2, H // s + 4)
        sw = max(2, W // s + 4)
        coarse = rng.randn(sh, sw).astype(np.float64)
        # Smooth so the upscale doesn't show grid artifacts.
        coarse = ndi.gaussian_filter(coarse, sigma=0.8)
        upscaled = ndi.zoom(coarse, s, order=3)[:H, :W]
        field += amp * upscaled
        total += amp
        amp *= persistence
    field /= total
    sd = float(np.std(field))
    if sd > 1e-9:
        field /= sd
    # Clip outliers so isolated peaks can't push a polyline across a neighbour.
    np.clip(field, -1.5, 1.5, out=field)
    return field


def subdivide_polyline(coords, max_seg_length):
    """Insert intermediate points so no segment is longer than max_seg_length."""
    if len(coords) < 2:
        return list(coords)
    new = [coords[0]]
    for i in range(len(coords) - 1):
        x1, y1 = coords[i]
        x2, y2 = coords[i + 1]
        d = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        n = max(1, int(np.ceil(d / max_seg_length)))
        for j in range(1, n + 1):
            t = j / n
            new.append((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t))
    return new


def displace_along_normal(coords, noise_field, amplitude,
                          taper_fraction=NOISE_TAPER_FRACTION):
    """Displace each interior vertex perpendicular to the local tangent by
    noise_field(x, y) * amplitude. Endpoints (junctions) are preserved exactly,
    and the displacement tapers to 0 within taper_fraction of each end so
    adjacent polylines stay connected at junctions without kinks."""
    n = len(coords)
    if n < 3:
        return list(coords)
    H, W = noise_field.shape
    out = [coords[0]]
    for i in range(1, n - 1):
        x, y = coords[i]
        tx = coords[i + 1][0] - coords[i - 1][0]
        ty = coords[i + 1][1] - coords[i - 1][1]
        tlen = (tx * tx + ty * ty) ** 0.5
        if tlen < 1e-9:
            out.append(coords[i])
            continue
        nx, ny = -ty / tlen, tx / tlen
        ix = max(0, min(W - 1, int(round(x))))
        iy = max(0, min(H - 1, int(round(y))))
        d = float(noise_field[iy, ix]) * amplitude
        # Cosine taper toward 0 near endpoints
        t_pos = i / (n - 1)
        if t_pos < taper_fraction:
            d *= 0.5 * (1 - np.cos(np.pi * t_pos / taper_fraction))
        elif t_pos > 1 - taper_fraction:
            d *= 0.5 * (1 - np.cos(np.pi * (1 - t_pos) / taper_fraction))
        out.append((x + nx * d, y + ny * d))
    out.append(coords[-1])
    return out


def chaikin_smooth(coords, iterations, preserve_endpoints=True):
    """Chaikin corner-cutting (each pass quarters every corner). Endpoints
    preserved so the polyline stays connected to its neighbours at junctions."""
    pts = list(coords)
    for _ in range(iterations):
        if len(pts) < 3:
            break
        new = [pts[0]] if preserve_endpoints else []
        for i in range(len(pts) - 1):
            p, q = pts[i], pts[i + 1]
            new.append((0.75 * p[0] + 0.25 * q[0], 0.75 * p[1] + 0.25 * q[1]))
            new.append((0.25 * p[0] + 0.75 * q[0], 0.25 * p[1] + 0.75 * q[1]))
        if preserve_endpoints:
            new.append(pts[-1])
        pts = new
    return pts


def get_adjacent_labels(polyline, label_image, samples=(0.25, 0.4, 0.5, 0.6, 0.75),
                        offset=2.0):
    """Sample labels on either side of a polyline at multiple positions.

    Returns the up-to-2 most-frequent labels seen, which represent the two
    provinces this polyline separates. Sampling perpendicular to the local
    tangent and aggregating across multiple positions makes this robust to
    noisy bits and tight curves."""
    H, W = label_image.shape
    counts = defaultdict(int)
    L = polyline.length
    if L < 1e-9:
        return []
    eps = max(1e-3, L * 0.001)
    for s in samples:
        d_along = s * L
        pt = polyline.interpolate(d_along)
        before = polyline.interpolate(max(0.0, d_along - eps))
        after = polyline.interpolate(min(L, d_along + eps))
        tx = after.x - before.x
        ty = after.y - before.y
        tlen = (tx * tx + ty * ty) ** 0.5
        if tlen < 1e-9:
            continue
        nx, ny = -ty / tlen, tx / tlen
        for sign in (-1, 1):
            sx = pt.x + nx * offset * sign
            sy = pt.y + ny * offset * sign
            ix = max(0, min(W - 1, int(round(sx))))
            iy = max(0, min(H - 1, int(round(sy))))
            lbl = int(label_image[iy, ix])
            if lbl > 0:
                counts[lbl] += 1
    return [lbl for lbl, _ in sorted(counts.items(), key=lambda kv: -kv[1])][:2]


def transform_polyline(polyline, label_image, province_meta,
                       noise_ll, noise_ls):
    """Returns (new_polyline, kind, label_pair) where:
      - kind ∈ {'land-land', 'land-sea', 'sea-sea', 'frame'}
      - label_pair is a frozenset of the two adjacent province ids (empty for frame)
    The label_pair is used downstream to merge stubs that all separate the same
    two provinces into one continuous polyline."""
    labels = get_adjacent_labels(polyline, label_image)
    if len(labels) >= 2:
        types = tuple(sorted(province_meta[l]["type"] for l in labels[:2]))
        label_pair = frozenset(labels[:2])
    else:
        types = ("frame",)
        label_pair = frozenset()

    coords = list(polyline.coords)
    if types == ("land", "land"):
        sub = subdivide_polyline(coords, LL_SUBDIVIDE)
        new = displace_along_normal(sub, noise_ll, LL_NOISE_AMPLITUDE)
        # One pass of Chaikin smoothing rounds the per-segment angle changes
        # into a continuous curve, killing the "stepped" look while keeping
        # the multi-scale wobble. Endpoints are preserved so junctions still
        # connect cleanly.
        new = chaikin_smooth(new, LL_POST_SMOOTH_ITER)
        kind = "land-land"
    elif types == ("land", "sea"):
        sub = subdivide_polyline(coords, LS_SUBDIVIDE)
        new = displace_along_normal(sub, noise_ls, LS_NOISE_AMPLITUDE)
        new = chaikin_smooth(new, LS_POST_SMOOTH_ITER)
        kind = "land-sea"
    elif types == ("sea", "sea"):
        # Aggressively simplify first so few control points remain (junctions
        # are preserved as endpoints), then Chaikin-smooth so the line through
        # those few points is a fluid curve. Province polygons that share this
        # boundary inherit the same low-vertex-count smooth geometry.
        simplified = LineString(coords).simplify(
            SS_PRE_SIMPLIFY_TOL, preserve_topology=False)
        new = chaikin_smooth(list(simplified.coords), SS_SMOOTH_ITER)
        kind = "sea-sea"
    else:
        new = coords
        kind = "frame"

    if len(new) < 2:
        return polyline, kind, label_pair
    return LineString(new), kind, label_pair


def vectorize(label_image, province_meta):
    """Returns (province_polygons, border_lines).

    Tracing each label's mask at level=0.5 (with padding to close at image edges)
    yields contours that share bit-identical coordinates between neighbours,
    which is what makes unary_union -> polygonize give a clean planar graph.
    """
    H, W = label_image.shape
    all_lines = []
    for lbl in province_meta:
        mask = label_image == lbl
        padded = np.pad(mask, 1, mode="constant", constant_values=False)
        contours = measure.find_contours(padded.astype(float), 0.5)
        for c in contours:
            c = c - 1.0  # undo padding offset
            if len(c) < 4:
                continue
            # clip to image bounds (padding can push points to -0.5 / W+0.5)
            c[:, 0] = np.clip(c[:, 0], 0, H)
            c[:, 1] = np.clip(c[:, 1], 0, W)
            # (row, col) -> (x, y)
            pts = [(float(p[1]), float(p[0])) for p in c]
            try:
                ls = LineString(pts)
            except Exception:
                continue
            if ls.is_valid and ls.length > 0:
                all_lines.append(ls)

    print(f"  contour line strings: {len(all_lines)}", file=sys.stderr)
    merged = unary_union(all_lines)

    # Consolidate the noded graph into one polyline per maximal degree-2 chain.
    # After linemerge, each polyline runs from junction to junction (or forms a
    # closed loop when there are no junctions on it).
    merged_lines = linemerge(merged)
    if isinstance(merged_lines, LineString):
        polylines = [merged_lines]
    elif isinstance(merged_lines, MultiLineString):
        polylines = list(merged_lines.geoms)
    else:
        polylines = []
    print(f"  polylines after linemerge: {len(polylines)}", file=sys.stderr)

    # Simplify polylines as a unit (junction endpoints are preserved by
    # Douglas-Peucker, so adjacent polylines stay connected at junctions).
    simplified_lines = []
    for ls in polylines:
        s = ls.simplify(SIMPLIFY_TOL, preserve_topology=False)
        if not s.is_empty and s.length > 0:
            simplified_lines.append(s)

    # Per-type transformation. Each polyline gets transformed once, so both
    # adjacent provinces will inherit the same boundary geometry. Endpoints
    # (junctions) are preserved exactly via tapering, so polylines stay
    # connected at junctions.
    if NATURAL_BORDERS:
        noise_ll = make_fractal_noise(H, W, scale=LL_NOISE_SCALE,
                                      seed=NOISE_SEED)
        noise_ls = make_fractal_noise(H, W, scale=LS_NOISE_SCALE,
                                      seed=NOISE_SEED + 1)
        transformed = []
        kinds = []
        label_pairs = []
        for pl in simplified_lines:
            new_pl, kind, pair = transform_polyline(
                pl, label_image, province_meta, noise_ll, noise_ls)
            transformed.append(new_pl)
            kinds.append(kind)
            label_pairs.append(pair)
        n_kind = defaultdict(int)
        for k in kinds:
            n_kind[k] += 1
        print(f"  transformed polylines by kind: {dict(n_kind)}", file=sys.stderr)
    else:
        transformed = simplified_lines
        kinds = ["land-land"] * len(simplified_lines)
        label_pairs = [frozenset()] * len(simplified_lines)

    # Aggressive Douglas-Peucker on each transformed polyline (Figma-style
    # "simplify path"). Endpoints are preserved, so junctions still line up
    # between adjacent polylines. Province polygons and foreground borders
    # both consume `transformed` downstream, so they stay aligned exactly.
    if FINAL_SIMPLIFY_TOL > 0:
        before = sum(len(ls.coords) for ls in transformed)
        simplified_t = []
        for ls in transformed:
            s = ls.simplify(FINAL_SIMPLIFY_TOL, preserve_topology=False)
            if not s.is_empty and s.length > 0 and len(s.coords) >= 2:
                simplified_t.append(s)
            else:
                simplified_t.append(ls)
        transformed = simplified_t
        after = sum(len(ls.coords) for ls in transformed)
        pct = 100 * after / max(1, before)
        print(f"  final simplify: {before} -> {after} vertices ({pct:.0f}%)",
              file=sys.stderr)

    # Re-node the transformed graph (in case any transformation introduced
    # incidental crossings).
    merged_t = unary_union(transformed)
    polys = list(polygonize(merged_t))
    print(f"  polygonized faces (raw): {len(polys)}", file=sys.stderr)

    # Union faces by their original-pixel province label so sub-pixel artifacts
    # at junctions are absorbed into the surrounding province.
    by_label = defaultdict(list)
    for poly in polys:
        rp = poly.representative_point()
        x = max(0, min(W - 1, int(round(rp.x))))
        y = max(0, min(H - 1, int(round(rp.y))))
        lbl = int(label_image[y, x])
        if lbl in province_meta:
            by_label[lbl].append(poly)

    province_polygons = []
    for lbl, faces in by_label.items():
        merged_face = unary_union(faces) if len(faces) > 1 else faces[0]
        # Fix self-intersections caused by noise displacement crossing a neighbour.
        if not merged_face.is_valid:
            merged_face = make_valid(merged_face)
        fill = province_meta[lbl]["fill"]
        ptype = province_meta[lbl]["type"]

        # make_valid can return Polygon, MultiPolygon, or GeometryCollection.
        candidates = []
        if isinstance(merged_face, Polygon):
            candidates = [merged_face]
        elif isinstance(merged_face, MultiPolygon):
            candidates = list(merged_face.geoms)
        else:
            for g in getattr(merged_face, "geoms", []):
                if isinstance(g, Polygon):
                    candidates.append(g)
                elif isinstance(g, MultiPolygon):
                    candidates.extend(g.geoms)
        for poly in candidates:
            if poly.area >= MIN_POLYGON_AREA:
                province_polygons.append((poly, fill, ptype))

    def _round_pt(p):
        return (round(p[0], 4), round(p[1], 4))

    kept_edges = set()
    for poly, _, _ in province_polygons:
        rings = [poly.exterior] + list(poly.interiors)
        for ring in rings:
            coords = list(ring.coords)
            for i in range(len(coords) - 1):
                kept_edges.add(frozenset((_round_pt(coords[i]),
                                          _round_pt(coords[i + 1]))))

    # Foreground = each transformed polyline emitted as one path so the SVG
    # stroke renders as a continuous curve. We drop frame polylines and any
    # polyline whose segments don't appear on a kept province boundary.
    eps = 0.5
    foreground = defaultdict(list)
    for ls, kind in zip(transformed, kinds):
        if kind == "frame":
            continue
        coords = list(ls.coords)
        has_kept = any(
            frozenset((_round_pt(coords[i]), _round_pt(coords[i + 1]))) in kept_edges
            for i in range(len(coords) - 1)
        )
        if has_kept:
            foreground[kind].append(ls)

    if EXCLUDE_FRAME:
        for k in list(foreground.keys()):
            kept = []
            for ls in foreground[k]:
                xs = [p[0] for p in ls.coords]
                ys = [p[1] for p in ls.coords]
                if (all(x <= eps for x in xs) or all(x >= W - eps for x in xs)
                        or all(y <= eps for y in ys) or all(y >= H - eps for y in ys)):
                    continue
                kept.append(ls)
            foreground[k] = kept

    return province_polygons, dict(foreground)


def _dedupe_coords(coords, eps=1e-3):
    """Drop consecutive vertices that round to the same SVG-output coords."""
    out = []
    for x, y in coords:
        if out and abs(x - out[-1][0]) < eps and abs(y - out[-1][1]) < eps:
            continue
        out.append((x, y))
    return out


def polygon_to_path_d(poly):
    parts = []
    rings = [poly.exterior] + list(poly.interiors)
    for ring in rings:
        coords = _dedupe_coords(list(ring.coords))
        if len(coords) < 3:
            continue
        parts.append(f"M{coords[0][0]:.3f},{coords[0][1]:.3f}")
        for x, y in coords[1:]:
            parts.append(f"L{x:.3f},{y:.3f}")
        parts.append("Z")
    return "".join(parts)


def line_to_path_d(ls):
    coords = _dedupe_coords(list(ls.coords))
    if len(coords) < 2:
        return ""
    parts = [f"M{coords[0][0]:.3f},{coords[0][1]:.3f}"]
    for x, y in coords[1:]:
        parts.append(f"L{x:.3f},{y:.3f}")
    return "".join(parts)


def overlays_png_data_uri(img, overlay_mask):
    H, W = img.shape[:2]
    rgba = np.zeros((H, W, 4), dtype=np.uint8)
    rgba[..., :3] = img
    rgba[..., 3] = overlay_mask.astype(np.uint8) * 255
    pil = Image.fromarray(rgba, mode="RGBA")
    buf = io.BytesIO()
    pil.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def write_svg(path, W, H, province_polygons, foreground, overlay_uri):
    """province_polygons: list of (Polygon, fill_hex, type_str)
    foreground: dict kind -> [LineString], kinds in
        {'land-land', 'land-sea', 'sea-sea'}.

    Layer order (back to front): background, provinces, named-provinces,
    borders, foreground, names, unit-positions, input-map.
    Empty placeholder groups are emitted so downstream tooling can populate
    them without altering ordering."""
    out = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'xmlns:xlink="http://www.w3.org/1999/xlink" '
        f'viewBox="0 0 {W} {H}" width="{W}" height="{H}">',
    ]

    # Background layer: union all land polygons into one path, all sea into another.
    by_type = defaultdict(list)
    type_fill = {}
    for poly, fill, ptype in province_polygons:
        by_type[ptype].append(poly)
        type_fill[ptype] = fill

    out.append('<g id="background" stroke="none">')
    for ptype in ("sea", "land"):  # sea first so land draws on top of any overlap
        polys = by_type.get(ptype, [])
        if not polys:
            continue
        merged = unary_union(polys) if len(polys) > 1 else polys[0]
        if isinstance(merged, Polygon):
            d = polygon_to_path_d(merged)
        elif isinstance(merged, MultiPolygon):
            d = "".join(polygon_to_path_d(g) for g in merged.geoms)
        else:
            d = ""
        if d:
            out.append(f'<path d="{d}" fill="{type_fill[ptype]}" '
                       f'class="bg-{ptype}"/>')
    out.append('</g>')

    out.append('<g id="provinces" stroke="none">')
    for poly, fill, _ptype in province_polygons:
        d = polygon_to_path_d(poly)
        if d:
            out.append(f'<path d="{d}" fill="{fill}"/>')
    out.append('</g>')

    out.append('<g id="named-provinces"></g>')

    out.append('<g id="borders" fill="none" stroke="#000" '
               'stroke-width="1" stroke-linecap="round" stroke-linejoin="round">')

    # Stable order; sea-sea last so its dashes draw on top of any meeting borders.
    extra_attrs = {
        "land-land": "",
        "land-sea": "",
        "sea-sea": f' stroke-dasharray="{SS_DASH}"',
    }
    for kind in ("land-land", "land-sea", "sea-sea"):
        lines = foreground.get(kind, [])
        if not lines:
            continue
        out.append(f'<g class="border-{kind}"{extra_attrs.get(kind, "")}>')
        for ls in lines:
            d = line_to_path_d(ls)
            if d:
                out.append(f'<path d="{d}"/>')
        out.append('</g>')

    out.append('</g>')

    out.append('<g id="foreground"></g>')
    out.append('<g id="names"></g>')
    out.append('<g id="unit-positions"></g>')

    out.append('<g id="input-map">')
    out.append(f'<image x="0" y="0" width="{W}" height="{H}" '
               f'xlink:href="{overlay_uri}"/>')
    out.append('</g>')

    out.append('</svg>')
    Path(path).write_text("\n".join(out), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="path to input PNG")
    ap.add_argument("output", help="path to output SVG")
    args = ap.parse_args()

    img = np.array(Image.open(args.input).convert("RGB"))
    H, W = img.shape[:2]
    print(f"Loaded {args.input}: {W}x{H}", file=sys.stderr)

    seg_border, real_border, land_like, sea_like, overlay_mask = build_masks(img)
    print(f"  seg_border px: {int(seg_border.sum())}, "
          f"real_border: {int(real_border.sum())}, "
          f"land: {int(land_like.sum())}, sea: {int(sea_like.sum())}, "
          f"overlay: {int(overlay_mask.sum())}", file=sys.stderr)

    label_image, province_meta = segment_provinces(seg_border, land_like, sea_like, overlay_mask)
    print(f"  provinces: {len(province_meta)}", file=sys.stderr)

    province_polygons, foreground = vectorize(label_image, province_meta)
    n_borders = sum(len(v) for v in foreground.values())
    by_kind = {k: len(v) for k, v in foreground.items()}
    print(f"  vector polygons: {len(province_polygons)}, "
          f"border edges: {n_borders} {by_kind}", file=sys.stderr)

    overlay_uri = overlays_png_data_uri(img, overlay_mask)
    write_svg(args.output, W, H, province_polygons, foreground, overlay_uri)
    print(f"Wrote {args.output}", file=sys.stderr)


if __name__ == "__main__":
    main()
